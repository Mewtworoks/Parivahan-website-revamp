# Parivahan LL/DL Journey — Reimagined (backend spine)

Build What Moves India submission. Fixes the three real failures of the
current Learner/Driving Licence flow, end-to-end:

  1. Silent failures / buggy apply  -> IDEMPOTENT apply (retry-safe, status always visible)
  2. "Come in the morning" chaos     -> FIXED time-slots, ATOMICALLY booked (no double-book)
  3. Pile-ups & endless waiting       -> LIVE queue: your token, your tester, real ETA

Secondary: a 2D scenario practice test (judgment over memorization).
Product is powered by an OpenAI model (Realtime voice agent). See write-up
for how Codex contributed to the build.

## Layout (your lane: backend + AI agent)
    app/booking_models.py   Application, RTO, Tester, Slot, Booking, QueueToken
    app/booking_engine.py   idempotent apply, atomic booking, live queue+ETA
    app/models.py           2D scenario schema + scoring (secondary test)
    app/seed_scenarios.py   seed scenario bank
    app/engine.py           test build/scoring/proctoring
    app/agent_tools.py      OpenAI Realtime function-tools + dispatcher
    app/main.py             FastAPI endpoints (full journey + test + agent)
    tests/test_concurrency.py  PROOF: 50 retries->1 app; 40 threads->1 slot winner

## Run
    pip install -r requirements.txt
    uvicorn app.main:app --reload      # http://127.0.0.1:8000/docs
    PYTHONPATH=. python tests/test_concurrency.py   # prove the guarantees

## The journey (each is one API call)
    POST /apply                  idempotent; retries return the same application
    GET  /application/{id}       transparency ledger, always readable
    GET  /slots                  free fixed time-slots
    POST /book                   atomic hold; 409 if just taken
    POST /checkin/{app_id}       issue live queue token
    GET  /queue/{token_id}       position + tester + live ETA
    POST /tester/{id}/call-next  advances the queue, everyone's ETA updates

## Why this is safe at scale (demonstrated, not claimed)
    - Idempotency key dedupes retry-storms that overload the current portal.
    - Atomic slot allocation = Postgres UNIQUE(slot_id) + ON CONFLICT in prod.
    - All state transitions are append-only ledger rows (auditable).
    - Mock/synthetic data only — no real Aadhaar/PAN/OTP/payment.
