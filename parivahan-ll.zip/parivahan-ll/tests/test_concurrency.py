"""
Proves the two backend guarantees that fix the real-world failures:
  1. Idempotent apply: 50 retries -> 1 application.
  2. Atomic booking: 40 threads racing one slot -> exactly 1 winner.

Run:  PYTHONPATH=. python tests/test_concurrency.py
"""
import concurrent.futures as cf
from app import booking_engine as be
from app.booking_engine import SlotTaken
from app.booking_models import LicenceKind


def prove_idempotency():
    key = "same-key-retried"
    ids = [be.apply("cit_1", LicenceKind.LL, "rto_x", key).id for _ in range(50)]
    unique = len(set(ids))
    print(f"idempotency: 50 submits (same key) -> {unique} application(s)")
    assert unique == 1, "retries created duplicates!"


def prove_atomic_booking():
    be.seed_demo("rto_race")
    slot = be.list_free_slots("rto_race")[0]
    apps = [be.apply(f"c{i}", LicenceKind.LL, "rto_race", f"i{i}") for i in range(40)]

    def grab(a):
        try:
            be.book_slot(a.id, slot.id)
            return True
        except SlotTaken:
            return False

    win = lose = 0
    with cf.ThreadPoolExecutor(max_workers=40) as ex:
        for ok in ex.map(grab, apps):
            win += ok
            lose += (not ok)
    print(f"atomic booking: 40 racing threads -> {win} winner, {lose} rejected")
    assert win == 1 and lose == 39, "double-booking occurred!"


if __name__ == "__main__":
    prove_idempotency()
    prove_atomic_booking()
    print("GUARANTEES HOLD ✅")
