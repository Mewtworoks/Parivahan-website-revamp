"""
FastAPI backend for the reimagined LL theory test.

Endpoints:
  POST /test/start                     -> begin a 15-scenario test
  GET  /test/{attempt_id}/next         -> next scenario (answer stripped)
  POST /test/{attempt_id}/answer       -> submit an answer, get feedback
  GET  /test/{attempt_id}/result       -> final result
  POST /test/{attempt_id}/proctor      -> proctoring subsystem posts events
  GET  /agent/tools                    -> OpenAI Realtime function-tool schema
  POST /agent/dispatch                 -> execute an agent tool call

Run:  uvicorn app.main:app --reload
"""

from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from datetime import date

from . import engine
from . import booking_engine as be
from .booking_engine import SlotTaken
from .booking_models import LicenceKind
from .seed_scenarios import scenario_by_id
from .agent_tools import AGENT_TOOL_SCHEMA, dispatch_tool

app = FastAPI(title="Parivahan LL Test — Reimagined", version="0.1.0")

# Let the teammate's frontend (any origin during hackathon) call in.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------- request bodies -------------------------------

class StartBody(BaseModel):
    citizen_id: str  # Aadhaar-linked ref; real auth handled upstream


class AnswerBody(BaseModel):
    scenario_id: str
    chosen_option_id: str
    time_taken_s: float


class ProctorBody(BaseModel):
    flag: str


class DispatchBody(BaseModel):
    tool: str
    arguments: dict


class ApplyBody(BaseModel):
    citizen_ref: str
    licence_kind: LicenceKind
    rto_id: str = "rto_ggn_01"
    idempotency_key: str      # client-generated; makes retries safe


class BookBody(BaseModel):
    application_id: str
    slot_id: str


# Seed a demo RTO (testers + fixed slot grid) at import time.
be.seed_demo("rto_ggn_01")


# ------------------------------- endpoints ---------------------------------

@app.post("/test/start")
def start_test(body: StartBody):
    attempt = engine.build_test(body.citizen_id)
    return {
        "attempt_id": attempt.id,
        "total_questions": len(attempt.scenario_ids),
        "pass_threshold": 9,
    }


@app.get("/test/{attempt_id}/next")
def next_question(attempt_id: str):
    attempt = engine.get_attempt(attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    sid = engine.next_scenario_id(attempt)
    if sid is None:
        return {"done": True, "index": attempt.current_index}
    scenario = scenario_by_id(sid)
    return {
        "done": False,
        "index": attempt.current_index,
        "total": len(attempt.scenario_ids),
        "scenario": scenario.public_view().model_dump(),
    }


@app.post("/test/{attempt_id}/answer")
def answer_question(attempt_id: str, body: AnswerBody):
    attempt = engine.get_attempt(attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    try:
        rec = engine.submit_answer(
            attempt, body.scenario_id, body.chosen_option_id, body.time_taken_s
        )
    except ValueError as e:
        raise HTTPException(400, str(e))

    scenario = scenario_by_id(body.scenario_id)
    return {
        "correct": rec.correct,
        # feedback teaches, per your "learning not just pass/fail" goal
        "explanation": scenario.explanation,
        "mv_act_ref": scenario.mv_act_ref,
        "score_so_far": attempt.score,
        "status": attempt.status.value,
    }


@app.get("/test/{attempt_id}/result")
def result(attempt_id: str):
    attempt = engine.get_attempt(attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    return {
        "status": attempt.status.value,
        "score": attempt.score,
        "total": len(attempt.scenario_ids),
        "pass_threshold": 9,
        "proctor_flags": attempt.proctor_flags,
    }


@app.post("/test/{attempt_id}/proctor")
def proctor(attempt_id: str, body: ProctorBody):
    attempt = engine.get_attempt(attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    engine.record_proctor_event(attempt, body.flag)
    return {"status": attempt.status.value, "flags": attempt.proctor_flags}


# --------------------- Journey: apply -> book -> queue ---------------------

@app.post("/apply")
def apply(body: ApplyBody):
    """Resilient, idempotent application. Retry-safe by design."""
    app_obj = be.apply(body.citizen_ref, body.licence_kind, body.rto_id,
                       body.idempotency_key)
    return {"application_id": app_obj.id, "status": app_obj.status.value,
            "ledger": [e.model_dump() for e in app_obj.ledger]}


@app.get("/application/{app_id}")
def application_status(app_id: str):
    """Transparency: the full journey ledger, always readable."""
    a = be.get_application(app_id)
    if not a:
        raise HTTPException(404, "Application not found")
    return {"application_id": a.id, "status": a.status.value,
            "booking_id": a.booking_id, "token_id": a.token_id,
            "ledger": [e.model_dump() for e in a.ledger]}


@app.get("/application/{app_id}/receipt")
def receipt(app_id: str):
    """
    Tamper-evident proof-of-journey. The hash chain means no one — no clerk,
    no middleman — can alter, insert, or drop a step without chain_valid
    flipping to false. This is the citizen's proof they earned their pass.
    """
    a = be.get_application(app_id)
    if not a:
        raise HTTPException(404, "Application not found")
    return a.receipt()


@app.get("/slots")
def free_slots(rto_id: str = "rto_ggn_01"):
    slots = be.list_free_slots(rto_id, date.today())
    return {"count": len(slots),
            "slots": [{"slot_id": s.id, "start": s.start.strftime("%H:%M"),
                       "tester_id": s.tester_id} for s in slots[:50]]}


@app.post("/book")
def book(body: BookBody):
    """Atomically hold a fixed time-slot. One winner per slot, guaranteed."""
    try:
        b = be.book_slot(body.application_id, body.slot_id)
    except SlotTaken:
        raise HTTPException(409, "That slot was just taken — pick another.")
    except KeyError as e:
        raise HTTPException(404, str(e))
    return {"booking_id": b.id, "start": b.start.strftime("%H:%M"),
            "tester_id": b.tester_id, "date": str(b.slot_date)}


@app.post("/checkin/{application_id}")
def checkin(application_id: str):
    """On arrival: issue a live queue token."""
    try:
        t = be.check_in(application_id)
    except KeyError as e:
        raise HTTPException(400, str(e))
    return {"token_id": t.id, "token_number": t.number, "tester_id": t.tester_id}


@app.get("/queue/{token_id}")
def queue(token_id: str):
    """What the citizen watches on their phone: position + live ETA."""
    try:
        return be.queue_status(token_id)
    except KeyError:
        raise HTTPException(404, "Token not found")


@app.post("/tester/{tester_id}/call-next")
def call_next(tester_id: str):
    """Tester-side: finish current, call next. Advances everyone's ETA."""
    nxt = be.call_next(tester_id)
    return {"now_serving": nxt.number if nxt else None}


# ------------------------- AI voice agent wiring ---------------------------

@app.get("/agent/tools")
def agent_tools():
    """Function-tool schema to register with the OpenAI Realtime session."""
    return {"tools": AGENT_TOOL_SCHEMA}


@app.post("/agent/dispatch")
def agent_dispatch(body: DispatchBody):
    """The Realtime agent calls a tool -> your client forwards it here."""
    try:
        return dispatch_tool(body.tool, body.arguments)
    except KeyError:
        raise HTTPException(400, f"Unknown tool: {body.tool}")


@app.get("/")
def root():
    return {"ok": True, "service": "LL test reimagined", "docs": "/docs"}
