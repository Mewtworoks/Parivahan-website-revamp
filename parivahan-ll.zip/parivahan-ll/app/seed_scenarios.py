"""
Seed bank of scenarios. In production this lives in Postgres; for the demo
we keep it in memory. Each entry is a full 3D scenario your teammate renders.

These are illustrative — enough variety to serve a real 15-question test and
show breadth to judges. Add more per competency to strengthen the bank.
The coordinates are simple placeholders; the renderer owns final art.
"""

from .models import Actor, CameraKeyframe, Competency, Option, Scenario

SCENARIOS: list[Scenario] = [
    Scenario(
        id="sc_ped_crosswalk_01",
        competency=Competency.PEDESTRIAN_SAFETY,
        difficulty=1,
        duration_s=6.0,
        prompt="A pedestrian steps onto the zebra crossing ahead as you approach. What do you do?",
        prompt_hi="आपके आगे ज़ेबरा क्रॉसिंग पर एक पैदल यात्री आ जाता है। आप क्या करेंगे?",
        scene_env="urban_intersection",
        actors=[
            Actor(id="ped1", kind="pedestrian", asset="ped_adult",
                  path=[[0, -4, 0, 2], [3, 0, 0, 2]]),
            Actor(id="zebra", kind="marking", asset="zebra_crossing"),
        ],
        camera=[
            CameraKeyframe(t=0.0, position=[0, 1.5, -8], look_at=[0, 0, 5]),
            CameraKeyframe(t=5.0, position=[0, 1.5, -3], look_at=[0, 0, 5]),
        ],
        options=[
            Option(id="a", label="Stop and let the pedestrian cross",
                   label_hi="रुकें और पैदल यात्री को जाने दें"),
            Option(id="b", label="Honk and continue", label_hi="हॉर्न बजाकर आगे बढ़ें"),
            Option(id="c", label="Swerve around them", label_hi="बगल से निकल जाएँ"),
        ],
        correct_option_id="a",
        explanation="Pedestrians on a zebra crossing have absolute right of way. "
                    "You must stop and allow them to cross safely.",
        mv_act_ref="Rule 8, RRR 1989",
    ),
    Scenario(
        id="sc_roundabout_01",
        competency=Competency.ROUNDABOUT,
        difficulty=2,
        duration_s=7.0,
        prompt="You reach a roundabout. A vehicle is already circulating from your right. What is correct?",
        prompt_hi="आप एक गोल चक्कर पर पहुँचते हैं। दाईं ओर से एक वाहन पहले से घूम रहा है। सही क्या है?",
        scene_env="roundabout",
        actors=[
            Actor(id="carR", kind="car", asset="car_sedan",
                  path=[[0, 8, 0, 0], [4, 0, 0, 3]]),
        ],
        camera=[CameraKeyframe(t=0.0, position=[0, 1.5, -10], look_at=[3, 0, 0])],
        options=[
            Option(id="a", label="Give way to the vehicle on the right, then enter",
                   label_hi="दाईं ओर के वाहन को रास्ता दें, फिर प्रवेश करें"),
            Option(id="b", label="Enter immediately, you have priority",
                   label_hi="तुरंत प्रवेश करें, प्राथमिकता आपकी है"),
            Option(id="c", label="Stop fully until the roundabout is empty",
                   label_hi="जब तक गोल चक्कर खाली न हो, पूरी तरह रुकें"),
        ],
        correct_option_id="a",
        explanation="At a roundabout, give way to traffic already circulating "
                    "from your right before entering.",
        mv_act_ref="Rule 10, RRR 1989",
    ),
    Scenario(
        id="sc_ambulance_01",
        competency=Competency.EMERGENCY_VEHICLE,
        difficulty=1,
        duration_s=6.0,
        prompt="An ambulance with siren approaches from behind in heavy traffic. What do you do?",
        prompt_hi="भारी ट्रैफ़िक में पीछे से सायरन बजाती एम्बुलेंस आ रही है। आप क्या करेंगे?",
        scene_env="urban_road",
        actors=[
            Actor(id="amb", kind="ambulance", asset="ambulance",
                  path=[[0, 0, 0, -12], [4, 0, 0, -2]], meta={"siren": True}),
        ],
        camera=[CameraKeyframe(t=0.0, position=[-2, 1.5, 0], look_at=[0, 0, -6])],
        options=[
            Option(id="a", label="Pull to the left and give a clear path",
                   label_hi="बाईं ओर होकर रास्ता दें"),
            Option(id="b", label="Speed up to stay ahead of it",
                   label_hi="आगे रहने के लिए गति बढ़ाएँ"),
            Option(id="c", label="Stop dead in your lane",
                   label_hi="अपनी लेन में ही रुक जाएँ"),
        ],
        correct_option_id="a",
        explanation="Emergency vehicles must be given free passage. Move left and "
                    "let it pass; never block or race it.",
        mv_act_ref="Rule 18, RRR 1989",
    ),
    Scenario(
        id="sc_overtake_01",
        competency=Competency.OVERTAKING,
        difficulty=3,
        duration_s=8.0,
        prompt="You want to overtake, but there is a solid yellow line and an oncoming vehicle. What is correct?",
        prompt_hi="आप ओवरटेक करना चाहते हैं, पर ठोस पीली रेखा है और सामने से वाहन आ रहा है। सही क्या है?",
        scene_env="two_lane_highway",
        actors=[
            Actor(id="lead", kind="car", asset="truck", path=[[0, 0, 0, 6], [6, 0, 0, 12]]),
            Actor(id="onc", kind="car", asset="car_sedan", path=[[0, 0.2, 0, 40], [6, 0.2, 0, 10]]),
            Actor(id="line", kind="marking", asset="solid_yellow"),
        ],
        camera=[CameraKeyframe(t=0.0, position=[0, 1.5, -6], look_at=[0, 0, 20])],
        options=[
            Option(id="a", label="Do not overtake; stay behind until it is safe and legal",
                   label_hi="ओवरटेक न करें; सुरक्षित और वैध होने तक पीछे रहें"),
            Option(id="b", label="Overtake quickly before the oncoming car arrives",
                   label_hi="सामने वाली गाड़ी आने से पहले जल्दी ओवरटेक करें"),
            Option(id="c", label="Overtake from the left",
                   label_hi="बाईं ओर से ओवरटेक करें"),
        ],
        correct_option_id="a",
        explanation="A solid yellow line prohibits overtaking. With an oncoming "
                    "vehicle it is doubly unsafe. Wait for a safe, legal gap.",
        mv_act_ref="Rule 2 & road markings, RRR 1989",
    ),
    Scenario(
        id="sc_sign_stop_01",
        competency=Competency.SIGN_RECOGNITION,
        difficulty=1,
        duration_s=5.0,
        prompt="You approach this sign at a junction. What does it require?",
        prompt_hi="आप जंक्शन पर इस चिन्ह के पास पहुँचते हैं। यह क्या आवश्यक करता है?",
        scene_env="urban_intersection",
        actors=[Actor(id="sign", kind="sign", asset="sign_stop", meta={"sign": "STOP"})],
        camera=[CameraKeyframe(t=0.0, position=[0, 1.5, -6], look_at=[1, 1, 2])],
        options=[
            Option(id="a", label="Come to a complete stop, then proceed when safe",
                   label_hi="पूरी तरह रुकें, फिर सुरक्षित होने पर आगे बढ़ें"),
            Option(id="b", label="Slow down only", label_hi="केवल गति धीमी करें"),
            Option(id="c", label="Maintain speed", label_hi="गति बनाए रखें"),
        ],
        correct_option_id="a",
        explanation="A STOP sign is mandatory — a full stop is required before "
                    "proceeding, regardless of whether the road looks clear.",
        mv_act_ref="Mandatory signs, RRR 1989",
    ),
    Scenario(
        id="sc_hazard_child_01",
        competency=Competency.HAZARD_ANTICIPATION,
        difficulty=2,
        duration_s=7.0,
        prompt="A ball rolls into the road from between parked cars. What should you anticipate and do?",
        prompt_hi="खड़ी गाड़ियों के बीच से एक गेंद सड़क पर आती है। आपको क्या अनुमान लगाना और करना चाहिए?",
        scene_env="residential_street",
        actors=[
            Actor(id="ball", kind="object", asset="ball", path=[[0, -3, 0, 4], [1.5, 0, 0, 4]]),
            Actor(id="parked", kind="car", asset="car_parked"),
        ],
        camera=[CameraKeyframe(t=0.0, position=[0, 1.5, -8], look_at=[0, 0, 5])],
        options=[
            Option(id="a", label="Slow down — a child may follow the ball",
                   label_hi="गति धीमी करें — गेंद के पीछे बच्चा आ सकता है"),
            Option(id="b", label="Continue, it is only a ball",
                   label_hi="आगे बढ़ें, यह सिर्फ़ एक गेंद है"),
            Option(id="c", label="Honk and speed up", label_hi="हॉर्न बजाकर गति बढ़ाएँ"),
        ],
        correct_option_id="a",
        explanation="A ball often means a child is about to run out. Anticipate the "
                    "hazard and slow down immediately.",
        mv_act_ref="Defensive driving principles",
    ),
    Scenario(
        id="sc_lane_01",
        competency=Competency.LANE_DISCIPLINE,
        difficulty=1,
        duration_s=6.0,
        prompt="On a multi-lane road you are driving slowly. Which lane should you use?",
        prompt_hi="बहु-लेन सड़क पर आप धीमे चल रहे हैं। आपको कौन-सी लेन इस्तेमाल करनी चाहिए?",
        scene_env="multi_lane_road",
        actors=[Actor(id="fast", kind="car", asset="car_sedan", path=[[0, 3, 0, -10], [4, 3, 0, 10]])],
        camera=[CameraKeyframe(t=0.0, position=[0, 2, -8], look_at=[0, 0, 6])],
        options=[
            Option(id="a", label="Keep to the left; leave right lanes for overtaking/faster traffic",
                   label_hi="बाईं ओर रहें; दाईं लेन ओवरटेक/तेज़ ट्रैफ़िक के लिए छोड़ें"),
            Option(id="b", label="Drive in the rightmost lane",
                   label_hi="सबसे दाईं लेन में चलें"),
            Option(id="c", label="Straddle two lanes", label_hi="दो लेन के बीच चलें"),
        ],
        correct_option_id="a",
        explanation="Slower traffic keeps left. The right lane is for overtaking "
                    "and faster-moving vehicles.",
        mv_act_ref="Rule 2, RRR 1989",
    ),
    Scenario(
        id="sc_night_01",
        competency=Competency.NIGHT_WEATHER,
        difficulty=2,
        duration_s=6.0,
        prompt="A vehicle approaches at night with high beams on. What is the correct response?",
        prompt_hi="रात में सामने से एक वाहन हाई बीम जलाकर आ रहा है। सही प्रतिक्रिया क्या है?",
        scene_env="night_highway",
        actors=[Actor(id="onc", kind="car", asset="car_sedan", path=[[0, 0, 0, 40], [5, 0, 0, 5]], meta={"highbeam": True})],
        camera=[CameraKeyframe(t=0.0, position=[0, 1.5, -6], look_at=[0, 0, 20])],
        options=[
            Option(id="a", label="Dip your headlights and look slightly to the left edge",
                   label_hi="अपनी हेडलाइट डिम करें और बाएँ किनारे की ओर देखें"),
            Option(id="b", label="Switch to high beam too", label_hi="आप भी हाई बीम कर दें"),
            Option(id="c", label="Close your eyes briefly", label_hi="कुछ पल आँखें बंद कर लें"),
        ],
        correct_option_id="a",
        explanation="Dip your beams to avoid dazzling others and reduce your own "
                    "glare by focusing on the left road edge.",
        mv_act_ref="Rule 20, RRR 1989",
    ),
    # --- add more here to deepen the bank; 15+ makes a full test comfortable ---
]


def scenario_by_id(sid: str) -> Scenario | None:
    return next((s for s in SCENARIOS if s.id == sid), None)
