"""
The engine that makes the flow *not break*.

Three guarantees, each answering one real failure of the current system:

  1. Idempotent apply — retrying a submit (flaky network, impatient user)
     never creates duplicates and never loses the application. The status is
     always readable. This is what stops the retry-storm that overloads infra.

  2. Atomic slot booking — under concurrency, a fixed time-slot goes to
     exactly one applicant. No double-booking, ever. Proven by a concurrency
     test in tests/test_concurrency.py.

  3. Live queue with recomputed ETA — on the day, each applicant has a token,
     a named tester and a wait estimate that updates as the tester clears people.

In-memory + a threading.Lock for the demo. In production the same shapes map
to Postgres with a UNIQUE constraint on (slot_id) and SELECT ... FOR UPDATE /
INSERT ... ON CONFLICT for the atomic booking — noted inline where it matters.
"""

from __future__ import annotations

import threading
import uuid
from datetime import date, datetime, time, timedelta, timezone

from .booking_models import (
    Application,
    AppStatus,
    Booking,
    JourneyEvent,
    LicenceKind,
    QueueToken,
    RTO,
    Slot,
    Tester,
    TokenStatus,
)

# ---- in-memory stores (swap for Postgres tables in prod) -----------------
_APPS: dict[str, Application] = {}
_APPS_BY_IDEM: dict[str, str] = {}          # idempotency_key -> application_id
_RTOS: dict[str, RTO] = {}
_TESTERS: dict[str, Tester] = {}
_SLOTS: dict[str, Slot] = {}
_BOOKINGS: dict[str, Booking] = {}
_TOKENS: dict[str, QueueToken] = {}
_TOKEN_SEQ: dict[str, int] = {}             # rto_id -> last token number

# One lock guards the mutations that must be atomic. In Postgres this is the
# row lock / unique constraint; here a single process lock is faithful enough
# to demonstrate the guarantee.
_LOCK = threading.Lock()


def _now() -> datetime:
    return datetime.now(timezone.utc)


# --------------------------------------------------------------------------
# Seed a demo RTO with testers and a full grid of fixed slots
# --------------------------------------------------------------------------

def seed_demo(rto_id: str = "rto_ggn_01", when: date | None = None) -> RTO:
    when = when or date.today()
    rto = RTO(id=rto_id, name="RTO Gurugram (demo)", city="Gurugram")
    _RTOS[rto.id] = rto

    testers = [
        Tester(id=f"{rto_id}_t1", name="Inspector A", rto_id=rto_id, avg_test_minutes=12),
        Tester(id=f"{rto_id}_t2", name="Inspector B", rto_id=rto_id, avg_test_minutes=10),
    ]
    for t in testers:
        _TESTERS[t.id] = t

    # Build the fixed slot grid: every slot_minutes from open to close.
    grid: list[time] = []
    cur = datetime.combine(when, rto.open_time)
    end = datetime.combine(when, rto.close_time)
    while cur < end:
        grid.append(cur.time())
        cur += timedelta(minutes=rto.slot_minutes)

    for t in testers:
        for start in grid:
            s = Slot(
                id=str(uuid.uuid4()),
                rto_id=rto_id,
                tester_id=t.id,
                slot_date=when,
                start=start,
            )
            _SLOTS[s.id] = s
    return rto


# --------------------------------------------------------------------------
# 1. Resilient, idempotent apply
# --------------------------------------------------------------------------

def apply(citizen_ref: str, licence_kind: LicenceKind, rto_id: str,
          idempotency_key: str) -> Application:
    """
    Submit an application. Safe to call repeatedly with the same
    idempotency_key — you always get the SAME application back, never a
    duplicate. This is the core fix for silent-failure + retry-storms.
    """
    with _LOCK:
        existing_id = _APPS_BY_IDEM.get(idempotency_key)
        if existing_id:
            return _APPS[existing_id]           # idempotent: return prior result

        app = Application(
            id=str(uuid.uuid4()),
            citizen_ref=citizen_ref,
            licence_kind=licence_kind,
            rto_id=rto_id,
            idempotency_key=idempotency_key,
            created_at=_now(),
        )
        app.log(AppStatus.SUBMITTED, "Application received.", _now())
        # Mock document verification — instant pass for the demo.
        app.log(AppStatus.VERIFIED, "Documents verified (mock).", _now())
        _APPS[app.id] = app
        _APPS_BY_IDEM[idempotency_key] = app.id
        return app


def get_application(app_id: str) -> Application | None:
    return _APPS.get(app_id)


# --------------------------------------------------------------------------
# 2. Atomic slot booking (no double-booking under concurrency)
# --------------------------------------------------------------------------

def list_free_slots(rto_id: str, on: date | None = None) -> list[Slot]:
    return [
        s for s in _SLOTS.values()
        if s.rto_id == rto_id and s.is_free and (on is None or s.slot_date == on)
    ]


class SlotTaken(Exception):
    pass


def book_slot(application_id: str, slot_id: str) -> Booking:
    """
    Atomically hold a slot for an application. If two requests race for the
    same slot, exactly one wins; the other gets SlotTaken. In Postgres this is
    a UNIQUE(slot_id) + INSERT ... ON CONFLICT DO NOTHING, or SELECT FOR UPDATE.
    """
    with _LOCK:
        slot = _SLOTS.get(slot_id)
        if slot is None:
            raise KeyError("Unknown slot")
        if not slot.is_free:
            raise SlotTaken(f"Slot {slot_id} already booked")

        app = _APPS.get(application_id)
        if app is None:
            raise KeyError("Unknown application")

        # claim it
        slot.booked_by_application = application_id
        booking = Booking(
            id=str(uuid.uuid4()),
            application_id=application_id,
            slot_id=slot.id,
            rto_id=slot.rto_id,
            tester_id=slot.tester_id,
            slot_date=slot.slot_date,
            start=slot.start,
            created_at=_now(),
        )
        _BOOKINGS[booking.id] = booking
        app.booking_id = booking.id
        app.log(AppStatus.SLOT_BOOKED,
                f"Slot booked: {slot.start.strftime('%H:%M')} with {slot.tester_id}.",
                _now())
        return booking


# --------------------------------------------------------------------------
# 3. On-the-day live queue with recomputed ETA
# --------------------------------------------------------------------------

def check_in(application_id: str) -> QueueToken:
    """Applicant arrives -> issue a token in their tester's queue."""
    with _LOCK:
        app = _APPS.get(application_id)
        if app is None or app.booking_id is None:
            raise KeyError("No booking to check in against")
        booking = _BOOKINGS[app.booking_id]

        _TOKEN_SEQ[booking.rto_id] = _TOKEN_SEQ.get(booking.rto_id, 0) + 1
        token = QueueToken(
            id=str(uuid.uuid4()),
            application_id=application_id,
            rto_id=booking.rto_id,
            tester_id=booking.tester_id,
            number=_TOKEN_SEQ[booking.rto_id],
            checked_in_at=_now(),
        )
        _TOKENS[token.id] = token
        app.token_id = token.id
        app.log(AppStatus.CHECKED_IN, f"Checked in. Token #{token.number}.", _now())
        return token


def _tester_queue(tester_id: str) -> list[QueueToken]:
    q = [t for t in _TOKENS.values()
         if t.tester_id == tester_id and t.status in (TokenStatus.WAITING, TokenStatus.IN_TEST)]
    return sorted(q, key=lambda t: t.number)


def queue_status(token_id: str) -> dict:
    """What the citizen sees on their phone: position, tester, live ETA."""
    token = _TOKENS.get(token_id)
    if token is None:
        raise KeyError("Unknown token")
    tester = _TESTERS[token.tester_id]
    q = _tester_queue(token.tester_id)

    # Everyone before us who isn't finished yet — split into the one currently
    # being tested vs. those still waiting, because they cost different time.
    before = [t for t in q if t.number < token.number]
    waiting_ahead = [t for t in before if t.status == TokenStatus.WAITING]
    in_test_ahead = [t for t in before if t.status == TokenStatus.IN_TEST]

    people_ahead = len(waiting_ahead) + len(in_test_ahead)
    # Full test time for each still-waiting person ahead; assume the in-test
    # person is on average halfway done.
    eta_min = int(len(waiting_ahead) * tester.avg_test_minutes
                  + len(in_test_ahead) * tester.avg_test_minutes * 0.5)

    return {
        "token_number": token.number,
        "tester": tester.name,
        "status": token.status.value,
        "people_ahead": people_ahead,
        "eta_minutes": eta_min,
        "someone_in_test": bool(in_test_ahead),
    }


def call_next(tester_id: str) -> QueueToken | None:
    """Tester-side: finish current (if any) and call the next waiting token."""
    with _LOCK:
        q = _tester_queue(tester_id)
        # mark any in-test as done
        for t in q:
            if t.status == TokenStatus.IN_TEST:
                t.status = TokenStatus.DONE
                t.finished_at = _now()
                app = _APPS.get(t.application_id)
                if app:
                    app.log(AppStatus.COMPLETED, "Test completed.", _now())
        # start next waiting
        for t in sorted(q, key=lambda x: x.number):
            if t.status == TokenStatus.WAITING:
                t.status = TokenStatus.IN_TEST
                t.started_at = _now()
                return t
        return None
